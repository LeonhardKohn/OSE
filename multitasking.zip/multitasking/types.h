typedef unsigned char uint8_t;
typedef unsigned int uint32;
typedef unsigned long long int uint64;
