void printstring(char *s);
void putachar(char c);
char readachar(void);
void printhex(uint64 x);
void uartInit();

// Gegenseitiges Ausschlussverfahren.




